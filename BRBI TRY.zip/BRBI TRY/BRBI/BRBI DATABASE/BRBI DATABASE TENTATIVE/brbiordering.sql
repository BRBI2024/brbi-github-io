-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2024 at 07:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brbiordering`
--

-- --------------------------------------------------------

CREATE TABLE `accounting` (
  `acc_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `code` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `accounting` (`acc_id`, `username`, `password`, `email`, `code`, `date`) VALUES
(1, 'accounting', 'accounting1', 'accounting@mail.com', '', '2024-06-20 07:29:42');

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `code` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `username`, `password`, `email`, `code`, `date`) VALUES
(1, 'admin', 'admin1', 'admin@mail.com', '', '2024-06-20 07:29:42'),
(2, 'brbiadmin', 'brbiadmin1234', 'brbiadmin@gmail.com', '', '2024-06-20 07:28:35');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE `dishes` (
  `d_id` int(222) NOT NULL,
  `rs_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `slogan` varchar(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dishes`
--

INSERT INTO `dishes` (`d_id`, `rs_id`, `title`, `slogan`, `price`, `img`) VALUES
(23, 7, 'Ballpen', 'Z', 69.00, '667918e53378a.png'),
(24, 8, 'Ballpen', 'C', 30.00, '667bccffc51cb.jpg'),
(25, 8, 'Ballpen', 'C', 30.00, '667cc93d703fd.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `remark`
--

CREATE TABLE `remark` (
  `id` int(11) NOT NULL,
  `frm_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remark` mediumtext NOT NULL,
  `remarkDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `remark`
--

INSERT INTO `remark` (`id`, `frm_id`, `status`, `remark`, `remarkDate`) VALUES
(23, 26, 'closed', 'Done', '2024-06-24 07:43:55'),
(24, 26, 'rejected', 'asdasd', '2024-06-24 08:31:09'),
(25, 26, 'closed', 'asdadasd', '2024-06-24 08:35:23'),
(26, 26, 'rejected', 'asdasdasd', '2024-06-24 09:00:03'),
(27, 26, 'closed', 'asdadasd', '2024-06-24 09:00:40'),
(28, 26, 'rejected', 'asdasdasd', '2024-06-24 09:13:14'),
(29, 27, 'closed', 'asdasdasd', '2024-06-24 09:13:56'),
(30, 0, 'closed', 'asdadasd', '2024-06-25 07:18:37'),
(31, 0, 'in process', 'asdadasd', '2024-06-25 07:30:23'),
(32, 0, 'closed', 'asdasdad', '2024-06-25 07:30:37'),
(33, 0, 'closed', 'asdasdasd', '2024-06-25 07:31:01'),
(34, 1, 'closed', 'asdadasda', '2024-06-25 07:33:29'),
(35, 1, 'rejected', 'asdsadasd', '2024-06-25 07:33:58'),
(36, 1, 'closed', 'asdadadasd', '2024-06-25 07:53:57'),
(37, 2, 'rejected', 'asdadasd', '2024-06-25 08:16:27'),
(38, 3, 'closed', 'asdasdasd', '2024-06-25 08:29:10'),
(39, 3, 'rejected', '1', '2024-06-25 08:33:41'),
(40, 4, 'closed', 'asdsadasd', '2024-06-25 08:43:41'),
(41, 5, 'closed', 'asdasdasd', '2024-06-25 08:45:00'),
(42, 6, 'rejected', 'no', '2024-06-25 08:46:33'),
(43, 4, 'rejected', '123123', '2024-06-25 09:17:23'),
(44, 7, 'closed', 'done', '2024-06-26 00:50:22'),
(45, 8, 'closed', 'asdadasd', '2024-06-26 06:04:47'),
(46, 13, 'closed', '11', '2024-06-27 06:35:43'),
(47, 14, 'closed', '11', '2024-06-27 07:06:34'),
(48, 15, 'closed', '1234', '2024-07-03 07:02:49'),
(49, 17, 'closed', '123123', '2024-07-03 07:10:30'),
(50, 16, 'closed', '11', '2024-07-03 08:03:59'),
(51, 18, 'closed', '11', '2024-07-03 08:04:15'),
(52, 19, 'closed', '11', '2024-07-04 07:52:44'),
(53, 22, 'closed', '11', '2024-07-05 01:21:47'),
(54, 20, 'rejected', '11', '2024-07-05 06:24:40'),
(55, 21, 'rejected', '11', '2024-07-05 06:29:38'),
(56, 23, 'rejected', '11', '2024-07-05 07:24:28'),
(57, 24, 'closed', '11', '2024-07-09 08:19:33');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `rs_id` int(222) NOT NULL,
  `c_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `url` varchar(222) NOT NULL,
  `o_hr` varchar(222) NOT NULL,
  `c_hr` varchar(222) NOT NULL,
  `o_days` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`rs_id`, `c_id`, `title`, `email`, `phone`, `url`, `o_hr`, `c_hr`, `o_days`, `address`, `image`, `date`) VALUES
(7, 0, 'Gaisano', 'gaisano@gmail.com', '09771087371', 'gaisano.com.ph', '--Select your Hours--', '--Select your Hours--', '--Select your Days--', ' Gaisano CDO ', '667bb710cde65.png', '2024-06-26 06:37:04'),
(8, 8, 'Ororama', 'ororamaga@gmail.com', '09771087371', 'ororama.com.ph', '8am', '8pm', 'Mon-Sat', 'Ororama Cogon', '667bb6d556246.png', '2024-06-26 06:36:05'),
(9, 8, 'SM', 'smdowntown@gmail.com', '09771087371', 'smdowntown.com', '9am', '9pm', 'Mon-Sat', 'SM', '66863823a009e.png', '2024-07-04 05:50:27');

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(222) NOT NULL,
  `c_name` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `f_name` varchar(222) NOT NULL,
  `l_name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `status` int(222) NOT NULL DEFAULT 1,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`, `status`, `date`) VALUES
(25, 'Tiano', 'BLU', 'Tiano', 'brbitiano@gmail.com', '09771087371', 'brbitiano1234', 'Tiano', 1, '2024-06-27 06:56:24'),
(26, 'Malitbog', 'BLU', 'Malitbog', 'brbimalitbog@gmail.com', '09771087371', 'brbimalitbog1234', 'Malitbog', 1, '2024-06-27 07:28:07');

-- --------------------------------------------------------

--
-- Table structure for table `users_orders`
--

CREATE TABLE `users_orders` (
  `o_id` int(222) NOT NULL,
  `u_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `quantity` int(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(222) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users_orders`
--

INSERT INTO `users_orders` (`o_id`, `u_id`, `title`, `quantity`, `price`, `status`, `date`) VALUES
(5, 16, 'Ballpen', 46, 69.00, 'closed', '2024-06-25 08:45:00'),
(7, 20, 'Ballpen', 124, 69.00, 'closed', '2024-06-26 00:50:22'),
(8, 20, 'Ballpen', 24, 69.00, 'closed', '2024-06-26 06:04:47'),
(9, 20, 'Ballpen', 2, 69.00, NULL, '2024-06-26 06:09:31'),
(10, 20, 'Ballpen', 1, 30.00, NULL, '2024-06-26 08:11:06'),
(11, 20, 'Ballpen', 1, 69.00, NULL, '2024-06-26 08:11:16'),
(12, 15, 'Ballpen', 78, 69.00, NULL, '2024-06-27 02:58:33'),
(13, 22, 'Ballpen', 1, 69.00, 'closed', '2024-06-27 06:35:43'),
(14, 25, 'Ballpen', 23, 69.00, 'closed', '2024-06-27 07:06:34'),
(15, 26, 'Ballpen', 1, 69.00, 'closed', '2024-07-03 07:02:49'),
(16, 26, 'Ballpen', 1, 30.00, 'closed', '2024-07-03 08:03:59'),
(17, 26, 'Ballpen', 1, 30.00, 'closed', '2024-07-03 07:10:30'),
(18, 25, 'Ballpen', 1, 30.00, 'closed', '2024-07-03 08:04:15'),
(19, 25, 'Ballpen', 1, 69.00, 'closed', '2024-07-04 07:52:44'),
(22, 26, 'Ballpen', 2, 69.00, 'closed', '2024-07-05 01:21:47'),
(23, 26, 'Ballpen', 1, 69.00, 'rejected', '2024-07-05 07:24:28'),
(24, 26, 'Ballpen', 8, 69.00, 'closed', '2024-07-09 08:19:33');

--
-- Indexes for dumped tables
--
ALTER TABLE `accounting`
  ADD PRIMARY KEY (`acc_id`);
--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `remark`
--
ALTER TABLE `remark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `users_orders`
--
ALTER TABLE `users_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

ALTER TABLE `accounting`
  MODIFY `acc_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dishes`
--
ALTER TABLE `dishes`
  MODIFY `d_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `remark`
--
ALTER TABLE `remark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `rs_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users_orders`
--
ALTER TABLE `users_orders`
  MODIFY `o_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
