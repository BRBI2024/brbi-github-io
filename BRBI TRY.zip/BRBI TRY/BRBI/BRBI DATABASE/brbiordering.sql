-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2024 at 08:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinefoodphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `code` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `username`, `password`, `email`, `code`, `date`) VALUES
(1, 'admin', 'admin1', 'admin@mail.com', '', '2024-06-20 07:29:42'),
(2, 'brbiadmin', 'brbiadmin1234', 'brbiadmin@gmail.com', '', '2024-06-20 07:28:35');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE `dishes` (
  `d_id` int(222) NOT NULL,
  `rs_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `slogan` varchar(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remark`
--

CREATE TABLE `remark` (
  `id` int(11) NOT NULL,
  `frm_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remark` mediumtext NOT NULL,
  `remarkDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `rs_id` int(222) NOT NULL,
  `c_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `url` varchar(222) NOT NULL,
  `o_hr` varchar(222) NOT NULL,
  `c_hr` varchar(222) NOT NULL,
  `o_days` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(222) NOT NULL,
  `c_name` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `f_name` varchar(222) NOT NULL,
  `l_name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `status` int(222) NOT NULL DEFAULT 1,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`, `status`, `date`) VALUES
(11, 'BLU-Sugbongcogon', 'BRBI', 'Sugbongcogon', 'brbisugbongcogon@gmail.com', '09771087371', 'c697cf8ba194a1d469775c9430d4cac2', 'XQ4Q+JHX, Butuan - Cagayan de Oro - Iligan Rd, Sugbongcogon, Misamis Oriental', 1, '2024-06-21 03:18:54'),
(12, 'BLU-Medina', 'BRBI', 'Medina', 'brbimedina@gmail.com', '09771087371', '9648f6b92e0f86cbd3ff165200a276a0', 'Medina, Misamis Oriental', 1, '2024-06-21 03:21:44'),
(13, 'BLU-Balingasag', 'BRBI', 'Balingasag', 'brbibalingasag@gmail.com', '09771087371', '3138e81cec780152a1e610654eee27ac', 'PQVJ+HMF, Butuan - Cagayan de Oro - Iligan Rd, Balingasag, Misamis Oriental', 1, '2024-06-21 03:23:40'),
(14, 'BLU-BalingasagMain', 'BRBI', 'Balingasag Main', 'brbibalingasagmain@gmail.com', '09771087371', '1f4bce5fef917595cf62022f501594d6', 'PQVH+J5M, Balingasag, Misamis Oriental', 1, '2024-06-21 03:25:30'),
(15, 'BLU-Manolo', 'BRBI', 'Manolo', 'brbimanolo@gmail.com', '09771087371', '5dc40a7f07fb0c218349ff9c45ce0804', '9V88+56 Manolo Fortich, Bukidnon', 1, '2024-06-21 03:27:43'),
(16, 'BLU-Malitbog', 'BRBI', 'Malitbog', 'brbimalitbog@gmail.com', '09771087371', '55d98641536afbe0819a0b5e25c6f6e4', 'GVPJ+62M, Street3, Malitbog, Bukidnon', 1, '2024-06-21 03:32:00'),
(17, 'BLU-Salay', 'BRBI', 'Salay', 'brbisalay@gmail.com', '09771087371', '56081ca8b6d068141441030c71932a8e', 'VQ6Q+CQH, Butuan - Cagayan de Oro - Iligan Rd, Salay, Misamis Oriental', 1, '2024-06-21 03:36:31'),
(18, 'BLU-Alubijid', 'BRBI', 'Alubijid', 'brbialubijid@gmail.com', '09771087371', 'ce542ee30ab7bb188bf932aa340beb1b', 'HFCF+CJ Alubijid, Misamis Oriental', 1, '2024-06-21 03:38:48'),
(19, 'BLU-Claveria', 'BRBI', 'Claveria', 'brbiclaveria@gmail.com', '09771087371', '1c15f0f21de03d86b4e4dd2cd0c488c1', 'JV7R+2R2, JV7R+2R3Villanueva, Claveria, Misamis Oriental', 1, '2024-06-21 03:41:47'),
(20, 'BLU-Baungon', 'BRBI', 'Baungon', 'brbibaungon@gmail.com', '09771087371', '2ed2b469a068120e446d1604746f42db', '8M7P+H6 Baungon, Bukidnon', 1, '2024-06-21 03:43:02'),
(21, 'BLU-TinAo', 'BRBI', 'TinAo', 'brbitinao@gmail.com', '09771087371', '81d3c929227febfff360a99cf21f1d3d', 'FPWW+HM Cagayan de Oro, Misamis Oriental', 1, '2024-06-21 03:44:09'),
(22, 'BLU-Tiano', 'BRBI', 'Tiano', 'brbitiano@gmail.com', '09771087371', 'c497a8454a1db5ae076221fde1886d61', 'FJHV+CC2, Tiano Brothers St, Cagayan de Oro, 9000 Misamis Oriental', 1, '2024-06-21 03:45:11');

-- --------------------------------------------------------

--
-- Table structure for table `users_orders`
--

CREATE TABLE `users_orders` (
  `o_id` int(222) NOT NULL,
  `u_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `quantity` int(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(222) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `remark`
--
ALTER TABLE `remark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `users_orders`
--
ALTER TABLE `users_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dishes`
--
ALTER TABLE `dishes`
  MODIFY `d_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `remark`
--
ALTER TABLE `remark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `rs_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users_orders`
--
ALTER TABLE `users_orders`
  MODIFY `o_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
